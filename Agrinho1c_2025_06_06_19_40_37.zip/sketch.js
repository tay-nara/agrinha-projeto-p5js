let jardineiro;
let plantas = [];
let temperatura = 10;
let totalArvores = 0;

let imgMachado;
let machado;

let tempoParaProximoCorte = 0;
let tempoParaProximaPraga = 0; // Novo: Tempo para a próxima praga/doença

const ESTADO_SAUDAVEL = 'saudavel';
const ESTADO_COMPRAGA = 'comPraga';
const ESTADO_COMDOENCA = 'comDoenca';

function preload() {
  imgMachado = loadImage("machado.png");
}

function setup() {
  createCanvas(600, 400);
  jardineiro = new Jardineiro(width / 2, height - 50);
  machado = new Machado();

  tempoParaProximoCorte = millis() + random(5000, 15000); // Entre 5 e 15 segundos
  tempoParaProximaPraga = millis() + random(10000, 25000); // Entre 10 e 25 segundos para a primeira praga
}

function draw() {
  let corFundo = lerpColor(color(217, 112, 26), color(219, 239, 208), map(totalArvores, 0, 100, 0, 1));
  background(corFundo);
  mostrarInformacao();

  jardineiro.mostrar();
  jardineiro.atualizar();

  // Atualiza e exibe as árvores
  for (let i = plantas.length - 1; i >= 0; i--) {
    let arvore = plantas[i];
    arvore.mostrar();
    arvore.atualizar(); // Permite que a árvore lide com seu estado (ex: morrer se não for tratada)

    // Remover árvores mortas por praga/doença
    if (arvore.estado === 'morta') {
      plantas.splice(i, 1);
      totalArvores--;
      temperatura += 7; // Penalidade maior por árvore morta por praga/doença
    }
  }

  // Lógica do machado
  machado.atualizar();
  machado.exibir();

  // Lógica das pragas/doenças
  gerenciarPragasDoencas();

  // Controle da temperatura
  temperatura += 0.01;
  if (temperatura > 30) temperatura = 30;
}

function mostrarInformacao() {
  textSize(20);
  fill(0);
  text("Temperatura: " + temperatura.toFixed(2), 10, 30);
  text("Árvores plantadas: " + totalArvores, 10, 50);
  text("Para movimentar o personagem use as setas do teclado.", 10, 70);
  text("Pressione 'Espaço' ou 'P' para plantar uma árvore.", 10, 90);
  text("Pressione 'C' para curar árvores.", 10, 110); // Nova instrução
}

// Classe que cria o jardineiro
class Jardineiro {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.emoji = '👨‍🌾';
    this.velocidade = 3;
    this.tamanho = 32;
  }

  atualizar() {
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= this.velocidade;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      this.x += this.velocidade;
    }
    if (keyIsDown(UP_ARROW)) {
      this.y -= this.velocidade;
    }
    if (keyIsDown(DOWN_ARROW)) {
      this.y += this.velocidade;
    }

    this.x = constrain(this.x, 0 + this.tamanho / 2, width - this.tamanho / 2);
    this.y = constrain(this.y, 0 + this.tamanho / 2, height - this.tamanho / 2);
  }

  mostrar() {
    textSize(this.tamanho);
    text(this.emoji, this.x, this.y);
  }

  podePlantar(arvoreX, arvoreY) {
    for (let arvore of plantas) {
      let d = dist(arvoreX, arvoreY, arvore.x, arvore.y);
      if (d < 30) {
        return false;
      }
    }
    if (machado.ativo && dist(arvoreX, arvoreY, machado.x, machado.y) < 50) {
      return false;
    }
    return true;
  }
}

function keyPressed() {
  if (key === ' ' || key === 'p') {
    let plantX = jardineiro.x;
    let plantY = jardineiro.y;

    if (jardineiro.podePlantar(plantX, plantY)) {
      let arvore = new Arvore(plantX, plantY);
      plantas.push(arvore);
      totalArvores++;
      temperatura -= 3;
      if (temperatura < 0) temperatura = 0;
    } else {
      console.log("Não é possível plantar aqui!");
    }
  }

  // Novo: Lógica para curar árvores
  if (key === 'c' || key === 'C') {
    let arvoreCurada = false;
    for (let arvore of plantas) {
      let d = dist(jardineiro.x, jardineiro.y, arvore.x, arvore.y);
      if (d < jardineiro.tamanho / 2 + arvore.tamanho / 2 + 10) { // Alcance de cura
        if (arvore.estado === ESTADO_COMPRAGA || arvore.estado === ESTADO_COMDOENCA) {
          arvore.curar();
          temperatura -= 1; // Pequeno bônus de temperatura por curar
          arvoreCurada = true;
          console.log("Árvore curada!");
        }
      }
    }
    if (!arvoreCurada) {
      console.log("Nenhuma árvore para curar por perto.");
    }
  }
}

class Arvore {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.emoji = '🌳';
    this.tamanho = 32;
    this.estado = ESTADO_SAUDAVEL; // Novo: estado da árvore
    this.tempoInfectada = 0; // Tempo em que a árvore foi infectada
    this.tempoParaMorrer = 7000; // 7 segundos para morrer se não for tratada
  }

  mostrar() {
    textSize(this.tamanho);
    let displayEmoji = this.emoji;

    if (this.estado === ESTADO_COMPRAGA) {
      displayEmoji = '🌳🐛'; // Árvore com praga
    } else if (this.estado === ESTADO_COMDOENCA) {
      displayEmoji = '🌳🦠'; // Árvore com doença
    } else if (this.estado === 'morta') {
      displayEmoji = '🪵'; // Tronco de árvore morta
    }

    text(displayEmoji, this.x, this.y);
  }

  atualizar() {
    if (this.estado === ESTADO_COMPRAGA || this.estado === ESTADO_COMDOENCA) {
      if (millis() - this.tempoInfectada > this.tempoParaMorrer) {
        this.estado = 'morta'; // A árvore morre se não for curada a tempo
        console.log("Uma árvore morreu devido a praga/doença!");
      }
    }
  }

  infectar(tipo) {
    if (this.estado === ESTADO_SAUDAVEL) { // Só infecta árvores saudáveis
      this.estado = tipo;
      this.tempoInfectada = millis();
      console.log(`Uma árvore foi infectada com ${tipo}!`);
    }
  }

  curar() {
    this.estado = ESTADO_SAUDAVEL;
    this.tempoInfectada = 0;
  }
}

class Machado {
  constructor() {
    this.x = -100;
    this.y = -100;
    this.tamanho = 50;
    this.ativo = false;
    this.velocidade = 5;
    this.alvoX = 0;
    this.alvoY = 0;
  }

  exibir() {
    if (this.ativo) {
      image(imgMachado, this.x - this.tamanho / 2, this.y - this.tamanho / 2, this.tamanho, this.tamanho);
    }
  }

  atualizar() {
    if (!this.ativo && millis() > tempoParaProximoCorte) {
      this.ativar();
    }

    if (this.ativo) {
      this.x = lerp(this.x, this.alvoX, 0.05);
      this.y = lerp(this.y, this.alvoY, 0.05);

      if (dist(this.x, this.y, this.alvoX, this.alvoY) < 5) {
        this.cortarArvore();
      }
    }
  }

  ativar() {
    this.ativo = true;
    if (plantas.length > 0) {
      // O machado agora pode mirar em qualquer árvore, não importa o estado
      let arvoreAlvo = random(plantas);
      this.alvoX = arvoreAlvo.x;
      this.alvoY = arvoreAlvo.y;

      let borda = floor(random(4));
      switch (borda) {
        case 0:
          this.x = random(width);
          this.y = -this.tamanho;
          break;
        case 1:
          this.x = width + this.tamanho;
          this.y = random(height);
          break;
        case 2:
          this.x = random(width);
          this.y = height + this.tamanho;
          break;
        case 3:
          this.x = -this.tamanho;
          this.y = random(height);
          break;
      }
    } else {
      this.x = random(width);
      this.y = random(height);
      setTimeout(() => this.desativar(), 1000);
    }
  }

  cortarArvore() {
    let arvoreCortada = false;
    for (let i = plantas.length - 1; i >= 0; i--) {
      let arvore = plantas[i];
      let d = dist(this.x, this.y, arvore.x, arvore.y);
      if (d < this.tamanho / 2 + arvore.tamanho / 2) {
        plantas.splice(i, 1);
        totalArvores--;
        temperatura += 5;
        arvoreCortada = true;
        break;
      }
    }

    if (arvoreCortada || plantas.length === 0) {
      this.desativar();
    } else {
      this.ativar(); // Tenta cortar outra árvore se a primeira não foi alcançável
    }
  }

  desativar() {
    this.ativo = false;
    this.x = -100;
    this.y = -100;
    tempoParaProximoCorte = millis() + random(5000, 15000);
  }
}

// Novo: Função para gerenciar o surgimento de pragas e doenças
function gerenciarPragasDoencas() {
  if (millis() > tempoParaProximaPraga && plantas.length > 0) {
    let arvoreAlvo = random(plantas);

    // Evita infectar árvores já infectadas ou mortas
    if (arvoreAlvo.estado === ESTADO_SAUDAVEL) {
      let tipoInfeccao = random([ESTADO_COMPRAGA, ESTADO_COMDOENCA]);
      arvoreAlvo.infectar(tipoInfeccao);
    }

    // Define o tempo para a próxima praga/doença
    tempoParaProximaPraga = millis() + random(10000, 25000); // Aparece a cada 10-25 segundos
  }
}